package Calendar;

import enums.Responses;

import java.util.Objects;

public class InviteClass implements Invite, Comparable<Invite>{
    private Responses status;
    private Account invitee;

    public InviteClass(Account invitee){
        this.status = Responses.UNANSWERED;
        this.invitee = invitee;
    }

    @Override
    public void setResponse(Responses response) {
        this.status = response;
    }

    @Override
    public Account getInvitee() {
        return invitee;
    }

    @Override
    public Responses getResponse() {
        return status;
    }

    @Override
    public String getInviteeEmail() {
        return invitee.getEmail();
    }

    @Override
    public int compareTo(Invite o) {
        return this.invitee.compareTo(o.getInvitee());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        InviteClass that = (InviteClass) o;
        return Objects.equals(invitee.getEmail(), that.invitee.getEmail());
    }
}
