package exceptions;

public class AccountNotFoundException extends Exception {
    private static final String MESSAGE = "Account %s does not exist.\n";
    private String name;
    public AccountNotFoundException(){
        super();
    }

    public AccountNotFoundException(String name){
        super();
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public String getMessage(){
        return MESSAGE;
    }
}
