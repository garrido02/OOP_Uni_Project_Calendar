package Calendar;

import dataStructures.Iterator;
import enums.Priorities;
import enums.Responses;

import java.time.LocalDateTime;

public interface Event {
    Priorities getPriorityLevel();
    String getName();
    String getFistTopic();

    Account getCreator();
    LocalDateTime getDate();
    void invite(Account user);
    void setResponse(Account user, String response);
    Iterator<Invite> inviteIterator();
    Iterator<String> topicsIterator();

    int getInvitationsNr(String type);
}
