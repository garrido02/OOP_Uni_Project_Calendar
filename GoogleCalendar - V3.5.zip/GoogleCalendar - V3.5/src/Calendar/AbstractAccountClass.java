package Calendar;


import enums.Responses;

import java.util.*;

public abstract class AbstractAccountClass implements Account, Comparable<Account> {
    private static final int NULL = 0;
    private String type;
    private String email;
    private Map<Account, List<Event>> events;


    protected AbstractAccountClass(String email, String type){
        this.email = email;
        this.type = type;
        this.events = new HashMap<>();
    }

    @Override
    public boolean canCreateHighPrio() {
        return this instanceof ManagerClass;
    }

    @Override
    public boolean canCreateMidPrio(){
        return this instanceof StaffClass;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public int compareTo(Account other) {
        return this.email.compareTo(other.getEmail());
    }

    @Override
    public boolean contains(Event e) {
        for (List<Event> event: events.values()) {
            ListIterator<Event> ite = event.listIterator();
            while (ite.hasNext()){
                Event ev = ite.next();
                if (ev.getName().equals(e.getName())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void addEvent(Event e) {
        List<Event> currentEvents = events.get(this);
        if (currentEvents == null){
            currentEvents = new ArrayList<>();
            currentEvents.add(e);
            events.put(e.getCreator(), currentEvents);
        } else {
            currentEvents.add(e);
            events.put(e.getCreator(), currentEvents);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        AbstractAccountClass that = (AbstractAccountClass) o;
        return Objects.equals(email, that.email);
    }

    @Override
    public boolean isBusy(Event e) {
        for (List<Event> event: events.values()){
            ListIterator<Event> ite = event.listIterator();
            while (ite.hasNext()){
                Event ev = ite.next();
                dataStructures.Iterator<Invite> invIterator = ev.inviteIterator();
                while (invIterator.hasNext()){
                    Invite invite = invIterator.next();
                    if (e.getDate().equals(ev.getDate()) && invite.getInvitee().equals(this) && invite.getResponse().equals(Responses.ACCEPT)){
                        return true;
                    }
                }
            }
            while (ite.hasNext()){

            }
        }
        return false;
    }

    @Override
    public Iterator<List<Event>> eventIterator() {
        Iterator<List<Event>> ite = events.values().iterator();
        return ite;
    }
}
