package Calendar;

import java.util.Iterator;
import java.util.List;

public interface Account {
    String getType();
    boolean canCreateHighPrio();
    boolean canCreateMidPrio();
    String getEmail();
    int compareTo(Account other);
    boolean contains(Event e);
    void addEvent(Event e);
    boolean isBusy(Event e);
    Iterator<List<Event>> eventIterator();
}
