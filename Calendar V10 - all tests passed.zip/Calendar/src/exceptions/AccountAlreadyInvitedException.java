package exceptions;

public class AccountAlreadyInvitedException extends Exception {
    private static final String MESSAGE = "Account %s was already invited.\n";

    public AccountAlreadyInvitedException(){
        super();
    }

    public String getMessage(){
        return MESSAGE;
    }
}
