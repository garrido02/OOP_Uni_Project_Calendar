package enums;

public enum Responses {
    ACCEPT,
    REJECT,
    UNANSWERED;
}
