package Calendar;

import dataStructures.Array;
import dataStructures.ArrayClass;
import dataStructures.Iterator;
import enums.Priorities;
import enums.Responses;

import java.time.LocalDateTime;

public class EventClass implements Event {
    private static final String CREATOR_DEFAULT_RESPONSE = "accept";
    private String name;
    private String topic;
    private Account creator;
    private Priorities priorityLevel;
    private LocalDateTime date;
    private Array<Invite> invites;

    public EventClass(String name, Account creator, String topic, Priorities priorityLevel, LocalDateTime date){
        this.name = name;
        this.creator = creator;
        this.topic = topic;
        this.priorityLevel = priorityLevel;
        this.date = date;
        this.invites = new ArrayClass<>();
        invite(creator);
        setResponse(creator, "accept");
    }

    @Override
    public Priorities getPriorityLevel() {
        return priorityLevel;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getTopic() {
        return topic;
    }

    @Override
    public Account getCreator() {
        return creator;
    }

    @Override
    public LocalDateTime getDate() {
        return date;
    }

    @Override
    public void invite(Account user) {
        invites.insertLast(new InviteClass(user));
    }

    @Override
    public void setResponse(Account user, String response) {
        Invite invite = new InviteClass(user);
        invites.get(invites.searchIndexOf(invite)).setResponse(response);
    }

    @Override
    public Iterator<Invite> inviteIterator() {
        return invites.iterator();
    }
}
