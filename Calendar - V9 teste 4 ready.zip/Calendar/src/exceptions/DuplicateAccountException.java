package exceptions;

public class DuplicateAccountException extends Exception {
    private static final String MESSAGE = "Account %s already exists.\n";

    public DuplicateAccountException (){
        super();
    }

    public String getMessage(){
        return MESSAGE;
    }
}
