package exceptions;

public class AccountAlreadyRepliedException extends Exception {
    private static final String MESSAGE = "Account %s has already responded.\n";

    public AccountAlreadyRepliedException(){
        super();
    }

    public String getMessage(){
        return MESSAGE;
    }
}
