package Calendar;

import enums.Priorities;

import java.time.LocalDateTime;
import java.util.ListIterator;

public interface Event {
    Priorities getPriorityLevel();
    String getName();
    String getFistTopic();

    Account getCreator();
    LocalDateTime getDate();
    void invite(Account user);
    void setResponse(Account user, String response);
    ListIterator<Invite> inviteIterator();
    ListIterator<String> topicsIterator();

    int getInvitationsNr(String type);
}
