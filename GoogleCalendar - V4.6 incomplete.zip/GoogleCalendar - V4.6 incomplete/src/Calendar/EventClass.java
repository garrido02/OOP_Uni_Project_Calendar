package Calendar;

import enums.Priorities;
import enums.Responses;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.StringTokenizer;

public class EventClass implements Event {
    private static final String CREATOR_DEFAULT_RESPONSE = "accept";
    private String name;
    private List<String> topic;
    private Account creator;
    private Priorities priorityLevel;
    private LocalDateTime date;
    private List<Invite> invites;

    public EventClass(String name, Account creator, String topic, Priorities priorityLevel, LocalDateTime date){
        this.name = name;
        this.creator = creator;
        this.priorityLevel = priorityLevel;
        this.date = date;
        this.invites = new ArrayList<>();
        addTopics(topic);
        invite(creator);
        setResponse(creator, CREATOR_DEFAULT_RESPONSE);
    }

    private void addTopics(String topic){
        StringTokenizer tokens = new StringTokenizer(topic);
        this.topic = new ArrayList<>(tokens.countTokens());
        while (tokens.hasMoreTokens()){
            this.topic.add(tokens.nextToken());
        }
    }

    @Override
    public Priorities getPriorityLevel() {
        return priorityLevel;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getFistTopic() {
        return topic.get(0);
    }

    @Override
    public Account getCreator() {
        return creator;
    }

    @Override
    public LocalDateTime getDate() {
        return date;
    }

    @Override
    public void invite(Account user) {
        invites.add(new InviteClass(user, this.name));
    }

    @Override
    public void setResponse(Account user, String response) {
        Invite invite = new InviteClass(user, this.name);
        invites.get(invites.indexOf(invite)).setResponse(response);
    }

    @Override
    public ListIterator<Invite> inviteIterator() {
        return invites.listIterator();
    }

    @Override
    public ListIterator<String> topicsIterator() {
        return topic.listIterator();
    }

    @Override
    public int getInvitationsNr(String type) {
        Responses response = Responses.valueOf(type);
        int result = 0;
        ListIterator<Invite> inviteListIterator = inviteIterator();
        while (inviteListIterator.hasNext()){
            Invite i = inviteListIterator.next();
            if (response == Responses.ALL){
                result++;
            } else if (i.getResponse().equals(response)){
                result++;
            }
        }
        return result;
    }
}
