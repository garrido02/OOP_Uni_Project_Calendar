package Calendar;

import enums.Priorities;
import enums.Responses;

import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.ListIterator;

public interface Event {
    Priorities getPriorityLevel();
    String getName();
    String getTopics();

    Account getCreator();
    LocalDateTime getDate();
    void invite(Account user);
    void setResponse(Account user, Responses response);
    Iterator<Invite> inviteIterator();

    int getInvitationsNr(String type);

    void setId(int id);
    int getId();
    int idCompareTo(Event other);

    boolean isUserInvited(Account invitee);

    boolean userAlreadyReplied(Account invitee);
    String getCreatorEmail();

    int compareByTopics(Event e2);

    void commonTopics(String[] t);

    int getCommonTopics();

	boolean hasUserRejected(Account invitee);
}
