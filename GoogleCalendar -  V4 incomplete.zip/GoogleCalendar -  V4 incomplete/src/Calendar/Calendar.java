package Calendar;

import enums.Accounts;
import enums.Priorities;
import exceptions.*;

import java.time.LocalDateTime;
import java.util.Iterator;

public interface Calendar {
    void addEvent(String email, String eventName, String eventPriority, LocalDateTime date, String topics) throws AccountNotFoundException, UnknownEventPriorityException,
            GuestAccountEventCreationException, StaffAccountEventCreationException,
            EventAlreadyExitsException, AccountIsBusyException;

    void removeEvent();
    Accounts checkType(String name);

    void addAccount(String email, String accountType) throws DuplicateAccountException,
            UnknownAccountTypeException;

    void removeAccount();

    void respondInvitation();

    void invite(String invitee, String eventCreator, String eventName) throws AccountNotFoundException, EventNotFoundInCreatorException,
            AccountAlreadyInvitedException;

    Iterator accountIterator();
    Iterator listEvents(String email) throws AccountNotFoundException, GuestAccountEventCreationException;

    Priorities checkPrio(String eventName, String name);
}
