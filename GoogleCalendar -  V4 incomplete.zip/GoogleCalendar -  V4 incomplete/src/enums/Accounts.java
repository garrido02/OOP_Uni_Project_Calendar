package enums;

public enum Accounts {
    STAFF,
    MANAGER,
    GUEST;
}
