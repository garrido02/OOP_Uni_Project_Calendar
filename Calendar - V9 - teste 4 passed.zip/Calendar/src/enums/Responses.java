package enums;

public enum Responses {
    ALL,
    ACCEPT,
    REJECT,
    UNANSWERED;

    public String toString(){
        return name().toLowerCase();
    }
}
