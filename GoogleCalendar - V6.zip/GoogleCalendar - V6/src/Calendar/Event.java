package Calendar;

import enums.Priorities;
import enums.Responses;

import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.ListIterator;

public interface Event {
    Priorities getPriorityLevel();
    String getName();
    String getFistTopic();

    Account getCreator();
    LocalDateTime getDate();
    void invite(Account user);
    void setResponse(Account user, Responses response);
    Iterator<Invite> inviteIterator();
    ListIterator<String> topicsIterator();

    int getInvitationsNr(String type);

    void setId(int id);
    int getId();
    int idCompareTo(Event other);

    boolean isUserInvited(Account invitee);

    boolean userAlreadyReplied(Account invitee);
    String getCreatorEmail();
}
