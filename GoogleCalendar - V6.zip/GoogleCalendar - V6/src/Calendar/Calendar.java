package Calendar;

import enums.Accounts;
import enums.Priorities;
import exceptions.*;

import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

public interface Calendar {
    void addEvent(String email, String eventName, String eventPriority, LocalDateTime date, String topics) throws AccountNotFoundException, UnknownEventPriorityException,
            GuestAccountEventCreationException, StaffAccountEventCreationException,
            EventAlreadyExitsException, AccountIsBusyException;

    void removeEvent(Event e);
    Accounts checkType(String name);

    void addAccount(String email, String accountType) throws DuplicateAccountException,
            UnknownAccountTypeException;

    void removeAccount();

    void respondInvitation(String invitee, String eventCreator, String eventName, String response) throws AccountNotFoundException, AccountNotInInvitedListException,
            AccountAlreadyRepliedException, AccountAlreadyOnAnEventException, EventNotFoundInCreatorException, UnknownResponseException;

    void invite(String invitee, String eventCreator, String eventName) throws AccountNotFoundException, EventNotFoundInCreatorException,
            AccountAlreadyInvitedException, AccountAlreadyOnAnEventException;

    Iterator<Account> accountIterator();
    Iterator<Event> listEvents(String email) throws AccountNotFoundException, GuestAccountEventCreationException;

    Priorities checkPrio(String eventName, String name);

    void setResponse(String invitee, String eventCreator, String eventName, String reject);

    boolean hasTimeConflict(String invitee, String eventCreator, String eventName);

    boolean isConflictedEventCreator(String invitee, Event e);

    void cancelEventParticipation(String invitee, Event e);
    Iterator<Event> getUserRejectedEvents(String invitee);

    String processSingleEvent(String eventCreator, String eventName) throws AccountNotFoundException, EventNotFoundInCreatorException;

    Iterator<Invite> inviteIterator(String eventName, String eventCreator);
}
