package enums;

public enum Responses {
    ALL,
    ACCEPT,
    REJECT,
    UNANSWERED;
}
