import Calendar.Calendar;
import enums.*;
import Calendar.*;
import exceptions.*;

import java.time.LocalDateTime;
import java.util.*;

public class Main {
    private static final String EXIT = "exit";
    private static final String BYE = "Bye!";
    private static final String ALL = "ALL";
    private static final String ACCEPT = "ACCEPT";
    private static final String REJECT = "REJECT";
    private static final String UNANSWERED = "UNANSWERED";
    private static final String GUEST_INVITED = "%s was invited.\n";
    private static final String STAFF_ACCEPTED = "%s accepted the invitation\n";
    private static final String ALL_ACCOUNTS = "All accounts:";
    private static final int NULL = 0;
    private static final String EVENT_CANCEL_TIME_CONFLICT = "%s promoted by %s was rejected.\n";
    private static final String EVENT_STATUS = "%s status [invited %d] [accepted %d] [rejected %d] [unanswered %d]\n";
    private static final String UNKNOWN_COMMAND = "Unknown command %s. Type help to see available commands\n";
    private static final String ACCOUNT_CREATED = "%s was registered.\n";
    private static final String ACCOUNT_LISTING = "%s [%s].\n";
    private static final String EVENT_CREATED = "%s is scheduled.\n";
    private static final String EVENT_CREATOR_CANCEL_TIME_CONFLICT = "%s promoted by %s was removed.\n";
    private static final String INVITEE_ATTENDING_OTHER_EVENT = "%s is already attending another event.\n";


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        startApp(in);
    }


    /**
     * DONE
     * @param in
     */
    private static void startApp(Scanner in) {
        String command;
        Calendar calendar = new CalendarClass();
        boolean isExit = false;
        do {
            StringTokenizer tokens = new StringTokenizer(in.nextLine());
            command = tokens.nextToken().toUpperCase();
            try {
                Commands c = Commands.valueOf(command);
                isExit = c.equals(EXIT);
                switch (c) {
                    case REGISTER -> processRegister(calendar, tokens);
                    case ACCOUNTS -> processAccounts(calendar);
                    case CREATE -> processCreate(calendar, tokens, in);
                    case EVENTS -> processListEvents(calendar, tokens);
                    case INVITE -> processInvite(calendar, tokens, in);
                    case RESPONSE -> processResponse(calendar, tokens, in);
                    case EVENT -> processSingleEvent(calendar, tokens);
                    case TOPICS -> processTopics(calendar, tokens);
                    case HELP -> processHelp();
                    case EXIT -> processExit();
                }
            } catch (IllegalArgumentException e) {
                processUnknownCommand(command);
            }
        } while (!isExit);
    }


    private static void processRegister(Calendar calendar, StringTokenizer tokens){
        String email = tokens.nextToken();
        String accountType = tokens.nextToken();

        try {
            calendar.addAccount(email, accountType);
            System.out.printf(ACCOUNT_CREATED, email);
        } catch (DuplicateAccountException e){
            System.out.printf(e.getMessage(), email);
        } catch (UnknownAccountTypeException e){
            System.out.printf(e.getMessage(), accountType);
        }
    }


    private static void processAccounts(Calendar calendar){
        Iterator<Account> ite = calendar.accountIterator();
        System.out.println(ALL_ACCOUNTS);
        while (ite.hasNext()){
            Account acc = ite.next();
            System.out.printf(ACCOUNT_LISTING, acc.getEmail(), acc.getType().toString());
        }
    }



    private static void processCreate(Calendar calendar, StringTokenizer tokens, Scanner in){
        String email = tokens.nextToken();
        String eventName = in.nextLine().trim();

        StringTokenizer t = new StringTokenizer(in.nextLine().trim());
        String eventPriority = t.nextToken();
        String year = t.nextToken();
        String month = t.nextToken();
        String day = t.nextToken();
        String hour = t.nextToken();
        LocalDateTime date = createDate(day, month, year, hour);

        String topics = in.nextLine().trim();

        try {
            calendar.addEvent(email, eventName, eventPriority, date, topics);
            System.out.printf(EVENT_CREATED, eventName);
        } catch (AccountNotFoundException e){
            System.out.printf(e.getMessage(), email);
        } catch (UnknownEventPriorityException e){
            System.out.println(e.getMessage());
        } catch (GuestAccountEventCreationException e){
            System.out.printf(e.getMessage(), email);
        } catch (StaffAccountEventCreationException e){
            System.out.printf(e.getMessage(), email);
        } catch (EventAlreadyExitsException e){
            System.out.printf(e.getMessage(), eventName, email);
        } catch (AccountIsBusyException e){
            System.out.printf(e.getMessage(), email);
        }
    }

    private static LocalDateTime createDate(String day, String month, String year, String hour){
        int y = Integer.parseUnsignedInt(year);
        int d = Integer.parseUnsignedInt(day);
        int m = Integer.parseUnsignedInt(month);
        int h = Integer.parseUnsignedInt(hour);
        return LocalDateTime.of(y,m,d,h, NULL);
    }

    private static void processListEvents(Calendar calendar, StringTokenizer tokens){
        String email = tokens.nextToken();
        try {
            Iterator<Event> eventIterator = calendar.listEvents(email);
            if (!eventIterator.hasNext()){
                System.out.printf("Account %s has no events.\n");
            } else {
                System.out.printf("Account %s events:\n", email);
                while (eventIterator.hasNext()){
                    Event e = eventIterator.next();
                    System.out.printf(EVENT_STATUS, e.getName(), e.getInvitationsNr(ALL), e.getInvitationsNr(ACCEPT), e.getInvitationsNr(REJECT), e.getInvitationsNr(UNANSWERED));
                }
            }
        } catch (AccountNotFoundException e){
            System.out.printf(e.getMessage(), email);
        } catch (GuestAccountEventCreationException e){
            System.out.printf(e.getMessage(), email);
        }
    }



    private static void processInvite(Calendar calendar, StringTokenizer tokens, Scanner in){
        String invitee = tokens.nextToken();
        StringTokenizer string = new StringTokenizer(in.nextLine());
        String eventCreator = string.nextToken();
        String eventName = string.nextToken();

        try {
            calendar.invite(invitee, eventCreator, eventName);
            if (Accounts.STAFF.equals(calendar.checkType(invitee)) && Priorities.HIGH.equals(calendar.checkPrio(eventName, eventCreator))){
                System.out.printf(STAFF_ACCEPTED, invitee);
                if (calendar.hasTimeConflict(invitee, eventCreator, eventName)){
                    Iterator<Event> rejectedEventIte = calendar.getUserRejectedEvents(invitee);
                    while(rejectedEventIte.hasNext()) {
                        Event e = rejectedEventIte.next();
                        if (!calendar.isConflictedEventCreator(invitee, e)) {
                            calendar.cancelEventParticipation(invitee, e);
                            System.out.printf(EVENT_CANCEL_TIME_CONFLICT, e.getName(), e.getCreator().getEmail());
                        } else {
                            calendar.removeEvent(e);
                            System.out.printf(EVENT_CREATOR_CANCEL_TIME_CONFLICT, e.getName(), e.getCreator().getEmail());
                        }
                    }
                }
            } else {
                System.out.printf(GUEST_INVITED, invitee);
            }
        } catch (AccountNotFoundException e){
            System.out.printf(e.getMessage(), e.getName());
        } catch (EventNotFoundInCreatorException e){
            System.out.printf(e.getMessage(), eventName, eventCreator);
        } catch (AccountAlreadyInvitedException e){
            System.out.printf(e.getMessage(), invitee, eventName);
        } catch (AccountAlreadyOnAnEventException e){
            calendar.setResponse(invitee, eventCreator, eventName, REJECT);
            System.out.printf(e.getMessage(), invitee);
        }
    }



    private static void processResponse(Calendar calendar, StringTokenizer tokens, Scanner in){
        String invitee = tokens.nextToken();
        StringTokenizer stringToken = new StringTokenizer(in.nextLine().trim());
        String eventCreator = stringToken.nextToken();
        String eventName = stringToken.nextToken();
        String response = in.nextLine().trim();
        try {
            //implement all
            calendar.respondInvitation(invitee, eventCreator, eventName, response);

        } catch (AccountNotFoundException e){
            System.out.printf(e.getMessage(), e.getName());
        } catch (AccountNotInInvitedListException e ){
            System.out.printf(e.getMessage(), invitee);
        } catch (AccountAlreadyRepliedException e ){
            System.out.printf(e.getMessage(), invitee);
        } catch (AccountAlreadyOnAnEventException e){
            System.out.printf(e.getMessage(), invitee);
        }
    }



    private static void processSingleEvent(Calendar calendar, StringTokenizer tokens){

    }



    private static void processTopics(Calendar calendar, StringTokenizer tokens){

    }


    /**
     * DONE
     */
    private static void processHelp(){
        System.out.println("Available commands:");
        for (HelpMsg s: HelpMsg.values()){
            System.out.println(s.getString());
        }
    }


    /**
     * DONE
     */
    private static void processExit(){
        System.out.println(BYE);
    }

    private static void processUnknownCommand(String command){
        System.out.printf(UNKNOWN_COMMAND, command);
    }
}