package exceptions;

public class UnknownEventPriorityException extends Exception {
    private static final String MESSAGE = "Unknown priority type.\n";

    public UnknownEventPriorityException(){
        super();
    }

    public String getMessage(){
        return MESSAGE;
    }
}
