package Calendar;

import enums.Accounts;
import enums.Priorities;
import enums.Responses;
import exceptions.*;

import java.time.LocalDateTime;
import java.util.*;


public class CalendarClass implements Calendar {
    private List<Account> users;

    public CalendarClass(){
        users = new ArrayList<>();
    }

    @Override
    public void addEvent(String email, String eventName, String eventPriority, LocalDateTime date, String topics) throws AccountNotFoundException,
            UnknownEventPriorityException, GuestAccountEventCreationException, StaffAccountEventCreationException,
            EventAlreadyExitsException, AccountIsBusyException {

        Account acc = new GuestClass(email);
        if (!users.contains(acc)){
            throw new AccountNotFoundException();
        }

        Account user = users.get(users.indexOf(acc));
        Priorities prio;
        try {
             prio = Priorities.valueOf(eventPriority.toUpperCase());
        } catch (IllegalArgumentException e){
            throw new UnknownEventPriorityException();
        }

        if (user instanceof GuestClass){
            throw new GuestAccountEventCreationException();
        }

        if (user instanceof StaffClass && prio.equals(Priorities.HIGH)){
            throw new StaffAccountEventCreationException();
        }

        Event e = new EventClass(eventName, user, topics, prio, date);
        if (user.contains(e)){
            throw new EventAlreadyExitsException();
        }

        if (user.isBusy(e)){
            throw new AccountIsBusyException();
        }

        user.addEvent(e);
        e.invite(user);
        e.setResponse(user, Responses.ACCEPT);
    }

    @Override
    public void removeEvent(Event e) {
        e.getCreator().removeEvent(e);
    }

    @Override
    public Accounts checkType(String name) {
        Account acc = new GuestClass(name);
        Account user = users.get(users.indexOf(acc));
        return user.getType();
    }

    @Override
    public void addAccount(String email, String accountType) throws DuplicateAccountException, UnknownAccountTypeException {
        try {
            Accounts type = Accounts.valueOf(accountType.toUpperCase());
            Account acc = whichType(email, type);

            if (users.contains(acc)){
                throw new DuplicateAccountException();
            }
            users.add(acc);
        } catch (IllegalArgumentException e){
            throw new UnknownAccountTypeException();
        }
    }

    private Account whichType(String email, Accounts type){
        Account acc = switch(type) {
            case GUEST -> new GuestClass(email);
            case STAFF -> new StaffClass(email);
            case MANAGER -> new ManagerClass(email);
        };
        return acc;
    }


    @Override
    public void removeAccount() {

    }

    @Override
    public void respondInvitation(String invitee, String eventCreator, String eventName, String response) throws AccountNotFoundException, AccountNotInInvitedListException,
            AccountAlreadyRepliedException, AccountAlreadyOnAnEventException {

    }

    @Override
    public void setResponse(String invitee, String eventCreator, String eventName, String reject) {
        Account creator = findUser(createTempUser(eventCreator));
        Event event = findEvent(creator, eventName);
        findUser(createTempUser(invitee)).respond(event, Responses.valueOf(reject.toUpperCase()));
    }

    @Override
    public boolean hasTimeConflict(String invitee, String eventCreator, String eventName) {
        boolean result = false;
        Account inviteeAcc = findUser(createTempUser(invitee));
        Account creatorAcc = findUser(createTempUser(eventCreator));
        Event event = findEvent(creatorAcc, eventName);
        Iterator<Event> eventsIterator = inviteeAcc.eventIterator();
        inviteeAcc.clearRejectedEvents();
        while (eventsIterator.hasNext()){
            Event e = eventsIterator.next();
            if (checkDatesCollision(e, event) && !e.equals(event)){
                inviteeAcc.addRejectedEvent(e);
                result = true;
            }
        }
        return result;
    }

    private boolean checkDatesCollision(Event e1, Event e2){
        return e1.getDate().equals(e2.getDate());
    }

    @Override
    public boolean isConflictedEventCreator(String invitee, Event e) {
        return e.getCreator().getEmail().equals(invitee);
    }

    @Override
    public void cancelEventParticipation(String invitee, Event e) {
        Account inviteeAcc = findUser(createTempUser(invitee));
        inviteeAcc.respond(e, Responses.REJECT);
    }

    @Override
    public Iterator<Event> getUserRejectedEvents(String invitee) {
        Account tmpUser = createTempUser(invitee);
        return findUser(tmpUser).rejectEventsIterator();
    }

    private Event findEvent(Account eventCreator, String eventName){
        return eventCreator.getEvent(eventName);
    }

    private Account findUser(Account tmpUser){
        return users.get(users.indexOf(tmpUser));
    }

    private Account createTempUser(String name){
        return new GuestClass(name);
    }

    @Override
    public void invite(String invitee, String eventCreator, String eventName) throws AccountNotFoundException, EventNotFoundInCreatorException, AccountAlreadyInvitedException, AccountAlreadyOnAnEventException {
        Account inviteeTmp = createTempUser(invitee);
        if (!users.contains(inviteeTmp)){
            throw new AccountNotFoundException(invitee);
        }
        Account creatorTmp = createTempUser(eventCreator);
        if (!users.contains(creatorTmp)){
            throw new AccountNotFoundException(eventCreator);
        }

        Account inviteeAcc = findUser(inviteeTmp);
        Account creatorAcc = findUser(creatorTmp);
        Event event = findEvent(creatorAcc, eventName);
        if (event == null) {
            throw new EventNotFoundInCreatorException();
        }

        if (event.isUserInvited(inviteeAcc)){
            throw new AccountAlreadyInvitedException();
        }

        if (inviteeAcc.isAttendingHighPrioEvent() && event.getPriorityLevel().equals(Priorities.HIGH)){
            throw new AccountAlreadyOnAnEventException();
        }

        creatorAcc.invite(inviteeAcc, event);

    }

    @Override
    public Iterator<Event> listEvents(String email) throws AccountNotFoundException, GuestAccountEventCreationException {
        Account acc = createTempUser(email);
        if (!users.contains(acc)){
            throw new AccountNotFoundException();
        }

        Account user = findUser(acc);

        if (user instanceof GuestClass){
            throw new GuestAccountEventCreationException();
        }

        Iterator<Event> ite = user.eventIterator();
        return ite;
    }

    @Override
    public Priorities checkPrio(String eventName, String name) {
        Account creatorTmp = createTempUser(name);
        Account user = findUser(creatorTmp);
        Event event = findEvent(user, eventName);
        return event.getPriorityLevel();
    }


    @Override
    public Iterator<Account> accountIterator() {
        users.sort((user1, user2) -> user1.compareTo(user2));
        return users.iterator();
    }

}
