package Calendar;

import enums.Responses;

public interface Invite {
    void setResponse(Responses response);
    Account getInvitee();
    Responses getResponse();
    String getEventName();
}
