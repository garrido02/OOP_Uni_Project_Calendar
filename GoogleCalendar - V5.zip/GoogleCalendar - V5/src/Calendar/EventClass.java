package Calendar;

import enums.Priorities;
import enums.Responses;

import java.time.LocalDateTime;
import java.util.*;

public class EventClass implements Event {
    private static final String CREATOR_DEFAULT_RESPONSE = "accept";
    private String name;
    private List<String> topic;
    private Account creator;
    private Priorities priorityLevel;
    private LocalDateTime date;
    private List<Invite> invites;
    private int id;

    public EventClass(String name, Account creator, String topic, Priorities priorityLevel, LocalDateTime date){
        this.name = name;
        this.creator = creator;
        this.priorityLevel = priorityLevel;
        this.date = date;
        this.invites = new ArrayList<>();
        addTopics(topic);
    }

    private void addTopics(String topic){
        StringTokenizer tokens = new StringTokenizer(topic);
        this.topic = new ArrayList<>(tokens.countTokens());
        while (tokens.hasMoreTokens()){
            this.topic.add(tokens.nextToken());
        }
    }

    @Override
    public Priorities getPriorityLevel() {
        return priorityLevel;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getFistTopic() {
        return topic.get(0);
    }

    @Override
    public Account getCreator() {
        return creator;
    }

    @Override
    public LocalDateTime getDate() {
        return date;
    }

    @Override
    public void invite(Account user) {
        Invite inv = new InviteClass(user, this.name);
        invites.add(inv);
        if (user != creator){
            user.addEvent(this);
        }
    }

    @Override
    public void setResponse(Account user, Responses response) {
        boolean found = false;
        Iterator<Invite> ite = invites.iterator();
        while (ite.hasNext() && !found){
            Invite i = ite.next();
            if (i.getInvitee().equals(user)){
                i.setResponse(response);
            }
        }
    }

    @Override
    public ListIterator<Invite> inviteIterator() {
        return invites.listIterator();
    }

    @Override
    public ListIterator<String> topicsIterator() {
        return topic.listIterator();
    }

    @Override
    public int getInvitationsNr(String type) {
        Responses response = Responses.valueOf(type);
        int result = 0;
        ListIterator<Invite> inviteListIterator = inviteIterator();
        while (inviteListIterator.hasNext()){
            Invite i = inviteListIterator.next();
            if (response == Responses.ALL){
                result++;
            } else if (i.getResponse().equals(response)){
                result++;
            }
        }
        return result;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public int idCompareTo(Event other) {
        if (this.id == other.getId()){
            return 0;
        } else if (this.id < other.getId()){
            return -1;
        } else {
            return 1;
        }
    }

    @Override
    public boolean isUserInvited(Account invitee) {
        boolean result = false;
        Iterator<Invite> ite = invites.listIterator();
        while (ite.hasNext() && !result) {
            Invite i = ite.next();
            if (i.getInvitee().equals(invitee)) {
                result = true;
            }
        }
        return result;
    }
}
