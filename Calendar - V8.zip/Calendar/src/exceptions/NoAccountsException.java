package exceptions;

public class NoAccountsException extends Exception {
    private static final String MESSAGE = "No accounts registered\n";

    public NoAccountsException(){
        super();
    }

    public String getMessage(){
        return MESSAGE;
    }
}
