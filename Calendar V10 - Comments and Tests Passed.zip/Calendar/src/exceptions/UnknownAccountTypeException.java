package exceptions;

public class UnknownAccountTypeException extends Exception{
    public UnknownAccountTypeException(){
        super();
    }

}
