package exceptions;

public class AccountIsBusyException extends Exception{
    public AccountIsBusyException(){
        super();
    }
}
