package exceptions;

public class EventNotFoundInCreatorException extends Exception {
    public EventNotFoundInCreatorException(){
        super();
    }

}
