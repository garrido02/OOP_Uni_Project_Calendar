package Calendar;

import enums.Accounts;
import enums.Priorities;
import exceptions.*;

import java.time.LocalDateTime;
import java.util.Iterator;

public interface Calendar {
    void addEvent(String email, String eventName, String eventPriority, LocalDateTime date, String topics) throws AccountNotFoundException, UnknownEventPriorityException,
            GuestAccountEventCreationException, StaffAccountEventCreationException,
            EventAlreadyExitsException, AccountIsBusyException;

    void removeEvent();
    Accounts checkType(String name);

    void addAccount(String email, String accountType) throws DuplicateAccountException,
            UnknownAccountTypeException;

    void removeAccount();

    void respondInvitation(String invitee, String eventCreator, String eventName, String response) throws AccountNotFoundException, AccountNotInInvitedListException,
            AccountAlreadyRepliedException, AccountAlreadyOnAnEventException;

    void invite(String invitee, String eventCreator, String eventName) throws AccountNotFoundException, EventNotFoundInCreatorException,
            AccountAlreadyInvitedException;

    Iterator accountIterator();
    Iterator listEvents(String email) throws AccountNotFoundException, GuestAccountEventCreationException;

    Priorities checkPrio(String eventName, String name);

    void setResponse(String invitee, String eventCreator, String eventName, String reject);

    boolean hasTimeConflict(String invitee, String eventCreator, String eventName);

    boolean isEventCreator(String invitee, String eventCreator, String eventName);

    void cancelOtherEventParticipation(String invitee, String eventCreator, String eventName);
}
