package Calendar;

import enums.Accounts;

import java.util.Iterator;
import java.util.List;

public interface Account {
    Accounts getType();
    boolean canCreateHighPrio();
    boolean canCreateMidPrio();
    String getEmail();
    int compareTo(Account other);
    boolean contains(Event e);
    void addEvent(Event e);
    boolean isBusy(Event e);
    Event getEvent(String eventName);
    Iterator<List<Event>> eventIterator();

    void invite(Account inviteeAcc, Event event);
}
