package Calendar;

import enums.Accounts;
import enums.Priorities;
import enums.Responses;
import exceptions.*;

import java.time.LocalDateTime;
import java.util.*;


public class CalendarClass implements Calendar {
    private List<Account> users;

    public CalendarClass(){
        users = new ArrayList<>();
    }

    @Override
    public void addEvent(String email, String eventName, String eventPriority, LocalDateTime date, String topics) throws AccountNotFoundException,
            UnknownEventPriorityException, GuestAccountEventCreationException, StaffAccountEventCreationException,
            EventAlreadyExitsException, AccountIsBusyException {

        Account acc = new GuestClass(email);
        if (!users.contains(acc)){
            throw new AccountNotFoundException();
        }

        Account user = users.get(users.indexOf(acc));
        Priorities prio;
        try {
             prio = Priorities.valueOf(eventPriority.toUpperCase());
        } catch (IllegalArgumentException e){
            throw new UnknownEventPriorityException();
        }

        if (user instanceof GuestClass){
            throw new GuestAccountEventCreationException();
        }

        if (user instanceof StaffClass && prio.equals(Priorities.HIGH)){
            throw new StaffAccountEventCreationException();
        }

        Event e = new EventClass(eventName, user, topics, prio, date);
        if (user.contains(e)){
            throw new EventAlreadyExitsException();
        }

        if (user.isBusy(e)){
            throw new AccountIsBusyException();
        }

        user.addEvent(e);
    }

    @Override
    public void removeEvent() {

    }

    @Override
    public Accounts checkType(String name) {
        Account acc = new GuestClass(name);
        Account user = users.get(users.indexOf(acc));
        return user.getType();
    }

    @Override
    public void addAccount(String email, String accountType) throws DuplicateAccountException, UnknownAccountTypeException {
        try {
            Accounts type = Accounts.valueOf(accountType.toUpperCase());
            Account acc = whichType(email, type);

            if (users.contains(acc)){
                throw new DuplicateAccountException();
            }
            users.add(acc);
        } catch (IllegalArgumentException e){
            throw new UnknownAccountTypeException();
        }
    }

    private Account whichType(String email, Accounts type){
        Account acc = switch(type) {
            case GUEST -> new GuestClass(email);
            case STAFF -> new StaffClass(email);
            case MANAGER -> new ManagerClass(email);
        };
        return acc;
    }


    @Override
    public void removeAccount() {

    }

    @Override
    public void respondInvitation(String invitee, String eventCreator, String eventName, String response) throws AccountNotFoundException, AccountNotInInvitedListException,
            AccountAlreadyRepliedException, AccountAlreadyOnAnEventException {

    }

    @Override
    public void setResponse(String invitee, String eventCreator, String eventName, String reject) {
    }

    @Override
    public boolean hasTimeConflict(String invitee, String eventCreator, String eventName) {
        return false;
    }

    @Override
    public boolean isEventCreator(String invitee, String eventCreator, String eventName) {
        return false;
    }

    @Override
    public void cancelOtherEventParticipation(String invitee, String eventCreator, String eventName) {

    }

    private Event findEvent(Account eventCreator, String eventName){
        return eventCreator.getEvent(eventName);
    }

    private Account findUser(Account tmpUser){
        return users.get(users.indexOf(tmpUser));
    }

    private Account createTempUser(String name){
        return new GuestClass(name);
    }

    @Override
    public void invite(String invitee, String eventCreator, String eventName) throws AccountNotFoundException, EventNotFoundInCreatorException, AccountAlreadyInvitedException {
        Account inviteeTmp = createTempUser(invitee);
        if (!users.contains(inviteeTmp)){
            throw new AccountNotFoundException(invitee);
        }
        Account creatorTmp = createTempUser(eventCreator);
        if (!users.contains(creatorTmp)){
            throw new AccountNotFoundException(eventCreator);
        }

        Account inviteeAcc = findUser(inviteeTmp);
        Account creatorAcc = findUser(creatorTmp);
        Event event = findEvent(creatorAcc, eventName);

        creatorAcc.invite(inviteeAcc, event);

    }

    @Override
    public Iterator<List<Event>> listEvents(String email) throws AccountNotFoundException, GuestAccountEventCreationException {
        Account acc = createTempUser(email);
        if (!users.contains(acc)){
            throw new AccountNotFoundException();
        }

        Account user = findUser(acc);

        if (user instanceof GuestClass){
            throw new GuestAccountEventCreationException();
        }

        return user.eventIterator();
    }

    @Override
    public Priorities checkPrio(String eventName, String name) {
        Account creatorTmp = createTempUser(name);
        Account user = findUser(creatorTmp);
        Event event = findEvent(user, eventName);
        return event.getPriorityLevel();
    }


    @Override
    public Iterator<Account> accountIterator() {
        users.sort((user1, user2) -> user1.compareTo(user2));
        return users.iterator();
    }

}
