package enums;

public enum Priorities {
    HIGH,
    MID;
}
