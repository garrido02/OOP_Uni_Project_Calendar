package Calendar;

import enums.Responses;

import java.util.Objects;

public class InviteClass implements Invite{
    private Responses status;
    private Account invitee;

    public InviteClass(Account invitee){
        this.status = Responses.UNANSWERED;
        this.invitee = invitee;
    }

    @Override
    public void setResponse(String response) {
        this.status = Responses.valueOf(response.toUpperCase());
    }

    @Override
    public Account getInvitee() {
        return invitee;
    }

    @Override
    public Responses getResponse() {
        return status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InviteClass that = (InviteClass) o;
        return Objects.equals(invitee, that.invitee);
    }
}
