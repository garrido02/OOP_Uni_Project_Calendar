package Calendar;


import enums.Accounts;
import enums.Responses;

import java.util.*;

public abstract class AbstractAccountClass implements Account, Comparable<Account> {
    private static final int NULL = 0;
    private Accounts type;
    private String email;
    private Map<Account, List<Event>> events;


    protected AbstractAccountClass(String email, String type){
        this.email = email;
        this.type = Accounts.valueOf(type.toUpperCase());
        this.events = new HashMap<>();
    }

    @Override
    public boolean canCreateHighPrio() {
        return this instanceof ManagerClass;
    }

    @Override
    public boolean canCreateMidPrio(){
        return this instanceof StaffClass;
    }

    @Override
    public Accounts getType() {
        return type;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public int compareTo(Account other) {
        return this.email.compareTo(other.getEmail());
    }

    @Override
    public boolean contains(Event e) {
        for (List<Event> event: events.values()) {
            ListIterator<Event> ite = event.listIterator();
            while (ite.hasNext()){
                Event ev = ite.next();
                if (ev.getName().equals(e.getName())) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void addEvent(Event e) {
        List<Event> currentEvents = events.get(this);
        if (currentEvents == null){
            currentEvents = new ArrayList<>();
            currentEvents.add(e);
            events.put(e.getCreator(), currentEvents);
        } else {
            currentEvents.add(e);
            events.put(e.getCreator(), currentEvents);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        AbstractAccountClass that = (AbstractAccountClass) o;
        return Objects.equals(email, that.email);
    }

    @Override
    public boolean isBusy(Event e) {
        for (List<Event> event: events.values()){
            ListIterator<Event> ite = event.listIterator();
            while (ite.hasNext()){
                Event ev = ite.next();
                dataStructures.Iterator<Invite> invIterator = ev.inviteIterator();
                while (invIterator.hasNext()){
                    Invite invite = invIterator.next();
                    if (checkIfDatesCollide(e, ev, invite)){
                        return true;
                    }
                }
            }
            while (ite.hasNext()){

            }
        }
        return false;
    }

    private boolean checkIfDatesCollide(Event e1, Event e2, Invite i){
        return e1.getDate().equals(e2.getDate()) && i.getInvitee().equals(this) && i.getResponse().equals(Responses.ACCEPT);
    }

    @Override
    public Iterator<List<Event>> eventIterator() {
        Iterator<List<Event>> ite = events.values().iterator();
        return ite;
    }

    @Override
    public void invite(Account inviteeAcc, Event event) {
        event.invite(inviteeAcc);
    }

    @Override
    public Event getEvent(String eventName) {
        Iterator<List<Event>> iterator = events.values().iterator();
        Event result = null;
        while (iterator.hasNext() && result == null){
            List<Event> eventList = iterator.next();
            ListIterator<Event> listIterator = eventList.listIterator();
            while (listIterator.hasNext()){
                Event e = listIterator.next();
                if (e.getName().equals(eventName)){
                    result = e;
                }
            }
        }
        return result;
    }
}
