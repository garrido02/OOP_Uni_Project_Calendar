package exceptions;

public class AccountAlreadyInvitedException extends Exception {
    public AccountAlreadyInvitedException(){
        super();
    }
}
