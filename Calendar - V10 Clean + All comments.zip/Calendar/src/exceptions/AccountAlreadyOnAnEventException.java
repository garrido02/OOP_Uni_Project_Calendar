package exceptions;

public class AccountAlreadyOnAnEventException extends Exception {
    public AccountAlreadyOnAnEventException(){
        super();
    }

}
