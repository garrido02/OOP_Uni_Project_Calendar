package exceptions;

public class UnknownResponseException extends Exception {
    public UnknownResponseException(){
        super();
    }
}
