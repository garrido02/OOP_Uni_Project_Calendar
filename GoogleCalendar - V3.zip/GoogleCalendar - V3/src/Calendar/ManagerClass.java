package Calendar;

import java.util.Objects;

public class ManagerClass extends AbstractAccountClass{
    private static final String TYPE = "manager";

    public ManagerClass(String email){ super(email, TYPE); }

}
